import os
import copy
import time
import cv2
import matplotlib
import numpy as np
import torch
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import xlrd
import xlwt
from sklearn import svm
from torch.utils.data import DataLoader
from xlutils.copy import copy as xlcopy
from PIL import Image
from matplotlib import pyplot as plt
from sklearn.metrics import roc_auc_score, precision_recall_fscore_support,accuracy_score


def saveToExcel(warning_rate,detect_rate,advloss,epoch,AUCscore):
    path = r'/mnt/videofireimg/cropvideo2-onecls/four_four/val/radius=0.001.xls'

    if os.path.exists(path):
        read = xlrd.open_workbook(path)
        write_workbook=xlcopy(read)
        worksheet=write_workbook.get_sheet(0)
        # worksheet = read.sheet_by_index(0)
    else:
        # 创建可写的workbook对象
        write_workbook = xlwt.Workbook(encoding='utf-8')
        # 创建工作表sheet
        worksheet = write_workbook.add_sheet('sheet1')

    worksheet.write(epoch, 0, warning_rate)
    worksheet.write(epoch, 1, detect_rate)
    worksheet.write(epoch, 2, advloss)
    worksheet.write(epoch,3,AUCscore)
    # 保存表
    write_workbook.save(path)


#trainer class for DROCC
class DROCCTrainer:
    """
    Trainer class that implements the DROCC algorithm proposed in
    https://arxiv.org/abs/2002.12718
    """

    def __init__(self, model, optimizer, lamda, radius, gamma, device):
        """Initialize the DROCC Trainer class

        Parameters
        ----------
        model: Torch neural network object
        optimizer: Total number of epochs for training.
        lamda: Weight given to the adversarial loss，对抗性损失的权重
        radius: Radius of hypersphere to sample points from.
        gamma: Parameter to vary projection.
        device: torch.device object for device to use.
        """     
        self.model = model
        self.optimizer = optimizer
        self.lamda = lamda
        self.radius = radius
        self.gamma = gamma
        self.device = device

    def train(self, size,train_loader, val_loader, learning_rate, lr_scheduler, total_epochs,
                only_ce_epochs=50, ascent_step_size=0.001, ascent_num_steps=50,model_dir='temp',
                metric='AUC'):
        """Trains the model on the given training dataset with periodic 
        evaluation on the validation dataset.

        Parameters
        ----------
        train_loader: Dataloader object for the training dataset.
        val_loader: Dataloader object for the validation dataset.
        learning_rate: Initial learning rate for training.
        total_epochs: Total number of epochs for training.
        only_ce_epochs: Number of epochs for initial pretraining.
        ascent_step_size: Step size for gradient ascent for adversarial 
                          generation of negative points.
        ascent_num_steps: Number of gradient ascent steps for adversarial 
                          generation of negative points.
        metric: Metric used for evaluation (AUC / F1).
        """
        best_score = -np.inf
        best_model = None
        self.ascent_num_steps = ascent_num_steps
        self.ascent_step_size = ascent_step_size
        # adv_sample_box=[]
        # data_sample_box=[]
        for epoch in range(total_epochs):
            #Make the weights trainable
            self.model.train()
            lr_scheduler(epoch, total_epochs, only_ce_epochs, learning_rate, self.optimizer)
            
            #Placeholder for the respective 2 loss values
            epoch_adv_loss = torch.tensor([0]).type(torch.float32).to(self.device)  #AdvLoss
            epoch_ce_loss = 0  #Cross entropy Loss

            # 每轮训练结束后，模型迭代，分类器能力增强，生成伪火焰样本的能力也需要增强
            batch_idx = -1
            o=1
            for data, target in train_loader:
                batch_idx += 1
                data, target = data.to(self.device), target.to(self.device)
                # Data Processing
                data = data.to(torch.float)
                # data_sample_box.append(data)
                # data = data[:,1:3,:,:].to(torch.float)
                target = target.to(torch.float)
                target = torch.squeeze(target)
                # target=torch.reshape(target,[1])

                self.optimizer.zero_grad()
                
                # Extract the logits for cross entropy loss
                logits = self.model(data)
                logits = torch.squeeze(logits, dim = 1)
                # binary_cross_entropy_with_logits的输入是网络输出的logits（未经sigmoid函数激活的），
                # 并且该函数会自动进行sigmoid函数激活处理，该损失函数已经内部自带了计算logit的操作，
                # 无需在传入给这个loss函数之前手动使用sigmoid/softmax将之前网络的输入映射到[0,1]之间
                ce_loss = F.binary_cross_entropy_with_logits(logits, target)
                # Add to the epoch variable for printing average CE Loss
                epoch_ce_loss += ce_loss

                '''
                Adversarial Loss is calculated only for the positive data points (label==0).
                '''
                if  epoch >= only_ce_epochs:
                    data = data[target == 0]
                    # img = data[0]
                    # img = img.cpu().numpy()
                    # img = np.transpose(img, (1, 2, 0))  # C*H*W -> H*W*C
                    # plt.imshow(img)
                    # plt.show()
                    # AdvLoss 
                    adv_lossbox = self.one_class_adv_loss(logits,data,epoch,batch_idx)
                    adv_loss=adv_lossbox[0]
                    # adv_sample_box.append(adv_lossbox[1])
                    # print("adv_loss",adv_loss)
                    epoch_adv_loss += adv_loss

                    loss = ce_loss + adv_loss * self.lamda
                else: 
                    # If only CE based training has to be done
                    loss = ce_loss
                
                # Backprop
                loss.backward()#求导，计算损失函数梯度，以便确定参数更新的方向和大小，实现反向传播
                # 根据计算得到的梯度，更新网络器参数，更新后的参数将被用于下一次的前向传递计算和反向传播计算
                self.optimizer.step()

                    
            epoch_ce_loss = epoch_ce_loss/(batch_idx + 1)  #Average CE Loss
            epoch_adv_loss = epoch_adv_loss/(batch_idx + 1) #Average AdvLoss
            # test_list=data_sample_box+adv_sample_box



            test_score= self.test(val_loader, metric)#进入test函数，里面有metric
            if test_score[0] > best_score:
                best_score = test_score[0]
                # best_model只是暂时保存了目前为止的最佳模型，并未参与训练（因为是深拷贝，不管self.model怎么变，bestmodel不变）
                # 参与训练的只有self.model
                best_model = copy.deepcopy(self.model)#原来的代码
                # self.model= copy.deepcopy(self.model)
                # params = list(best_model.named_parameters())
                # print('best model:',params)

            print('Epoch: {}, CE Loss: {}, AdvLoss: {}, {}: {}'.format(
                epoch, epoch_ce_loss.item(), epoch_adv_loss.item(),
                metric, test_score))
            self.save2(model_dir,epoch)
        self.model = copy.deepcopy(best_model)
        print('\nBest test {}: {}'.format(
            metric, best_score
        ))
        print("test**************")

    def test(self,test_loader, metric):
        """Evaluate the model on the given test dataset.

        Parameters
        ----------
        test_loader: Dataloader object for the test dataset.
        metric: Metric used for evaluation (AUC / F1).
        """        
        self.model.eval()
        label_score = []
        batch_idx = -1
        # for data, target in test_loader:
        # i=0
        for data,target in test_loader:
            # if i<20:
            #     target=torch.from_numpy(np.zeros((len(data))))
            # else:
            #     target=torch.from_numpy(np.ones((len(data))))
            # i+=1
            batch_idx += 1
            data, target = data.to(self.device), target.to(self.device)
            data = data.to(torch.float)
            # data = data[:, 1:3, :, :].to(torch.float)
            target = target.to(torch.float)
            target = torch.squeeze(target)

            logits = self.model(data)
            sigmoid_logits = torch.sigmoid(logits)
            scores = logits
            logits = torch.squeeze(logits, dim=1)
            # logits=logits.detach().numpy().reshape(len(logits),1)
            # scores = svm.predict(logits)
            label_score += list(zip(target.cpu().data.numpy().tolist(),
                                            scores.tolist()))
        # Compute test score
        labels, scores = zip(*label_score)
        labels = np.array(labels)
        scores = np.array(scores)
        if metric == 'F1':
            # Evaluation based on https://openreview.net/forum?id=BJJLHbb0-
            thresh = np.percentile(scores, 50)
            y_pred = np.where(scores >= thresh, 1, 0)#scores >= thresh取1，scores <= thresh取0
            prec, recall, test_metric, _ = precision_recall_fscore_support(
                labels, y_pred)
            test_metric=recall[0]
            acc = accuracy_score(labels, y_pred)
            print("prec", prec)
            print("recall", recall)
            print("acc", acc)
            # 从预测结果的角度来统计：预测为火焰的样本中，有多少是真正的火焰样本

            print("火焰预测精度", prec[0], "误警率", np.size(np.where(labels==1 and prec==0))/np.size(np.where(labels==1)))
            # 从真实的样本集来统计：总的火焰样本中，找回了多少个火焰样本
            print("火焰检测率", recall[0])
        if metric == 'AUC':
            # Evaluation based on https://openreview.net/forum?id=BJJLHbb0-
            thresh = np.percentile(scores, 50)
            # thresh = np.percentile(scores, 25)
            print("testloader thresh:",thresh)
            y_pred = np.where(scores >= thresh, 1, 0)#scores >= thresh取1，scores <= thresh取0
            # y_pred=scores
            # y=np.sum(y_pred)
            prec, recall, test_metric, _ = precision_recall_fscore_support(
                labels, y_pred)
            #所有无火样本中，被判为有火的概率
            print("误警率:",np.sum(y_pred[np.where(labels==1)]==0)/np.sum(labels==1))
            #所有有火样本中，被判为有火的概率,也就是召回率，TP/(TP+FN)=TP/P
            print("火焰检测率:",recall[0])

            # test_metric = roc_auc_score(labels, scores)  # labels真实标签，scores预测标签
            test_metric=0
            # saveToExcel(np.sum(y_pred[np.where(labels == 1)] == 0) / np.sum(labels == 1), recall[0], advloss, epoch,test_metric)


        return test_metric,thresh
        
    
    def one_class_adv_loss(self,logits, x_train_data,epoch,batch_idx):
        """Computes the adversarial loss:
        0为火焰类，视为正常类，1为无火类，视为异常类
        1) Sample points initially at random around the positive training
            data points
        2) Gradient ascent to find the most optimal point in set N_i(r) 
            classified as +ve (label=0). This is done by maximizing 
            the CE loss wrt label 0
        3) Project the points between spheres of radius R and gamma * R 
            (set N_i(r))
        4) Pass the calculated adversarial points through the model, 
            and calculate the CE loss wrt target class 0
        
        Parameters
        ----------
        x_train_data: Batch of data to compute loss on.
        """
        batch_size = len(x_train_data)
        # Randomly sample points around the training data
        # We will perform SGD on these to find the adversarial points




        x_adv = torch.randn(x_train_data.shape).to(self.device).detach().requires_grad_()
        x_adv_sampled = x_adv + x_train_data

        # img = x_adv_sampled[0]
        # img = img.cpu().detach().numpy()
        # img = np.transpose(img, (1, 2, 0))  # C*H*W -> H*W*C
        # plt.imshow(img)
        # plt.show()

        for step in range(self.ascent_num_steps):
            # 按公式不断更新x_adv_sampled，每10步按公式投影一次x_adv_sampled到Ni(r)集
            with torch.enable_grad():#允许计算梯度
                # new_targets = torch.zeros(batch_size, 1).to(self.device)
                new_targets = torch.ones(batch_size, 1).to(self.device)
                new_targets = torch.squeeze(new_targets)
                new_targets = new_targets.to(torch.float)
                # new_targets=torch.reshape(new_targets,[1])
                
                logits = self.model(x_adv_sampled)         
                logits = torch.squeeze(logits, dim = 1)
                # 公式Adversarial search:第一步，计算网络相对于负标签（异常点）的损失
                new_loss = F.binary_cross_entropy_with_logits(logits, new_targets)

                grad = torch.autograd.grad(new_loss, [x_adv_sampled])[0]#公式Adversarial search:第二步，梯度上升找对抗点，先求梯度
                grad_norm = torch.norm(grad, p=2, dim = tuple(range(1, grad.dim())))#公式Adversarial search:第二步求梯度的二范数
                grad_norm = grad_norm.view(-1, *[1]*(grad.dim()-1))
                grad_normalized = grad/grad_norm #公式Adversarial search:第二步，梯度除以梯度的二范数
            with torch.no_grad():#公式Adversarial search:第二步，结果相加，就是沿梯度上升，ascent_step_size就是η，
                x_adv_sampled.add_(self.ascent_step_size * grad_normalized)

            if (step + 1) % 10==0:#每10步投影一次异常点到Ni(r)集，公式Adversarial search中第三步：投影

                # Project the normal points to the set N_i(r)
                h = x_adv_sampled - x_train_data
                norm_h = torch.sqrt(torch.sum(h**2, 
                                                dim=tuple(range(1, h.dim()))))
                # clamp(输入张量,min,max)函数的功能将输入input张量每个元素的值压缩到区间[min, max]，并返回结果到一个新张量
                alpha = torch.clamp(norm_h, self.radius, 
                                    self.gamma * self.radius).to(self.device)#论文，算法步骤Adversarial search中第三步，where α=
                # Make use of broadcast to project h
                proj = (alpha/norm_h).view(-1, *[1] * (h.dim()-1))#公式Adversarial search中第三步
                h = proj * h#论文，算法步骤Adversarial search中第三步
                x_adv_sampled = x_train_data + h  #These adv_points are now on the surface of hyper-sphere

        adv_pred = self.model(x_adv_sampled)
        adv_pred = torch.squeeze(adv_pred, dim=1)
        # adv_loss = F.binary_cross_entropy_with_logits(adv_pred, (new_targets * 0))#原始
        adv_loss = F.binary_cross_entropy_with_logits(adv_pred, (new_targets * 1))
        # logits=logits.reshape(len(logits),1)
        # adv_pred = adv_pred.reshape(len(adv_pred), 1)
        # X=np.vstack([logits.detach().numpy(),adv_pred.detach().numpy()])
        # y=np.vstack([np.zeros([len(logits),1]),np.ones([len(adv_pred),1])])
        # svc = svm.SVC(kernel='linear', C=1, gamma='auto').fit(X, y)


        # if epoch==10 and batch_idx==0:
        #     path = r'/mnt/videofireimg/cropvideo2-onecls/four_four/val/train_advpoints10epoch.xls'
        #     # 创建可写的workbook对象
        #     workbook = xlwt.Workbook(encoding='utf-8')
        #     # 创建工作表sheet
        #     worksheet = workbook.add_sheet('sheet1')
        #     k=0
        #     for o in range(128):
        #         img = x_adv_sampled[o]
        #         # img = img.cpu().detach().numpy()
        #         # img = np.transpose(img, (1, 2, 0))  # C*H*W -> H*W*C
        #         # min_val = np.min(img)
        #         # max_val = np.max(img)
        #         # img_data_clamped = (img - min_val) / (max_val - min_val)
        #         x_train_da=x_train_data[o]
        #         # x_train_da=np.transpose(x_train_da,(1,2,0))
        #         # transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
        #         # img = transform(cropped_image)
        #         img = img.reshape((1, 3, 4, 4))
        #         img = img.to(self.device)
        #         img = img.to(torch.float)
        #         logits_adv=self.model(img)
        #
        #         x_train_da = x_train_da.reshape((1, 3, 4, 4))
        #         x_train_da = x_train_da.to(self.device)
        #         x_train_da = x_train_da.to(torch.float)
        #         logits_fire=self.model(x_train_da)
        #         for row in range(4):
        #             for col in range(4):
        #                 # worksheet.write(k, 0,float(img[0][row,col:col+1]))
        #                 # worksheet.write(k, 1,float(img[1][row,col:col+1]))
        #                 # worksheet.write(k, 2,float(img[2][row,col:col+1]))
        #                 worksheet.write(k, 0, float(logits_adv))
        #
        #                 # worksheet.write(k, 7, float(x_train_da[0][row, col:col + 1]))
        #                 # worksheet.write(k, 8, float(x_train_da[1][row, col:col + 1]))
        #                 # worksheet.write(k, 9, float(x_train_da[2][row, col:col + 1]))
        #                 worksheet.write(k, 1, float(logits_fire))
        #                 k+=1
        #     # 保存表
        #     workbook.save(path)

                # plt.imsave("/mnt/videofireimg/cropvideo2-onecls/four_four/fake/fire{}.png".format(o), img_data_clamped)
                # plt.imsave("/mnt/videofireimg/cropvideo2-onecls/four_four/true/fire{}.png".format(o), x_train_da)
            # print("epochPPPPPPPPPPPPPPPPPPPPPPPP",epoch)


        return adv_loss,x_adv_sampled

    def save(self, path,metric):
        torch.save(self.model.state_dict(),os.path.join(path, '4px-AUC-SGD-lr0.001-r0.2-gamma1.0.pt'.format(metric)))

    def save2(self, path,i):
        torch.save(self.model.state_dict(),os.path.join(path, '4px-modelPlus-AUC{}.pt'.format(i)))

    def load(self, path,str):
        self.model.load_state_dict(torch.load(os.path.join(path,str)))


    def val(self,path_src,s,vthresh):
        scorebox = np.array([])

        for i in range(1,len(os.listdir(path_src))+1):
            img = Image.open(path_src + '{}_'.format(s)+str(i)+'.png')
            print('{}_'.format(s)+str(i)+'.png')

            transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
            img = transform(img)
            img = torch.reshape(img, (1, 3, 4, 4))
            img = img.to(self.device)
            img = img.to(torch.float)

            logits = self.model(img)
            logits = torch.squeeze(logits, dim=1)

            scores = logits

            # scores.cpu().data.numpy()-----GPU数据转到CPU，再将tensor转为numpy
            scores = np.array(scores.cpu().data.numpy())
            scorebox = np.hstack((scorebox, scores))
        print(scorebox)
        thresh =vthresh
        print('val thresh', thresh)
        y_pred = np.where(scorebox >= thresh, 1, 0)  # scores >= thresh取1，scores <= thresh取0
        print(y_pred)
        fire_index=np.where(y_pred==0)+np.ones((1,np.size(np.where(y_pred==0))))
        return fire_index

    def real_time_val(self,f,vthresh,cutsize,frame):

        s_time = time.time()
        img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        # 宽度854再加42，左右各加21，高度288再加48，上下各加24,分块56x56
        # borderType = cv2.BORDER_REFLECT指边界反射填充(以边界为轴对称填充)
        # top_btm = 0
        # left_rgt = 5
        # replicate = cv2.copyMakeBorder(img, top_btm, top_btm, left_rgt, left_rgt, borderType=cv2.BORDER_REFLECT)
        # replicate = cv2.cvtColor(replicate, cv2.COLOR_BGR2RGB)
        # imgori = replicate
        imgori=img

        high, width, channel = imgori.shape
        row=high
        col=width
        index = 1
        thresh = vthresh
        print('val thresh', thresh)
        w=h = cutsize
        y_pred=[]
        new_img = Image.new('RGB', (width, high))
        for i in range(row // cutsize):
            for j in range(col // cutsize):
                cropped_image = imgori[i * cutsize:cutsize * (i + 1),
                                cutsize * j:cutsize * (j + 1)]  # Slicing to crop the image

                transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
                img = transform(cropped_image)
                img = img.reshape((1, 3, cutsize, cutsize))
                img = img.to(self.device)
                img = img.to(torch.float)

                logits = self.model(img)
                logits = torch.squeeze(logits, dim=1)
                scores = logits
                if scores>=thresh:
                    imgn = Image.new("RGB", (w, h), "black")  # 新建图像
                    y_pred.append(1)
                else:
                    # img_pil = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                    img_pil = Image.fromarray(cropped_image)
                    imgn = img_pil
                    # indexbox.append(index)
                    y_pred.append(0)
                index=index+1

                new_img.paste(imgn, (j * h, i * w))
        e_time = time.time()
        runtime = e_time - s_time
        # new_img.save(r'/mnt/videofireimg/cropvideo2-onecls/32x32/val/4px_result_frame{}.png'.format(f))

        return runtime,y_pred

    def batch_val(self,label,cutsize,frame):
        s_time = time.time()
        # img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        # 宽度854再加42，左右各加21，高度288再加48，上下各加24,分块56x56
        # borderType = cv2.BORDER_REFLECT指边界反射填充(以边界为轴对称填充)
        # top_btm = 0
        # left_rgt = 1
        # replicate = cv2.copyMakeBorder(img, top_btm, top_btm, left_rgt, left_rgt, borderType=cv2.BORDER_REFLECT)
        # replicate = cv2.cvtColor(replicate, cv2.COLOR_BGR2RGB)
        # imgori = replicate
        imgori = frame

        high, width, channel = imgori.shape
        row = high
        col = width
        k1=1
        k2=1
        for i in range(row // cutsize):
            for j in range(col // cutsize):
                cropped_image = imgori[i * cutsize:cutsize * (i + 1),
                                cutsize * j:cutsize * (j + 1)]  # Slicing to crop the image

                # transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
                # img = transform(cropped_image)
                # img = img.reshape((1, 3, 4, 4))
                # img = img.to(self.device)
                # img = img.to(torch.float)

                if label[i*320+j] == 0:
                    cv2.imwrite(r'/mnt/videofireimg/flamevideo-onecls/four_four/tempval/fire/4px-frame{}.png'.format(k1),cropped_image)
                    k1=k1+1
                else:
                    cv2.imwrite(r'/mnt/videofireimg/flamevideo-onecls/four_four/tempval/nofire/4px-frame{}.png'.format(k2),cropped_image)
                    k2 = k2 + 1

        e_time = time.time()
        runtime = e_time - s_time

        return runtime


    def test2(self,test_loader, metric,vthresh):
        s_time = time.time()
        self.model.eval()
        label_score = []
        batch_idx = -1

        for data,target in test_loader:
            batch_idx += 1
            data, target = data.to(self.device), target.to(self.device)
            data = data.to(torch.float)
            target = target.to(torch.float)
            target = torch.squeeze(target)

            logits = self.model(data)
            sigmoid_logits = torch.sigmoid(logits)
            scores = logits
            logits = torch.squeeze(logits, dim=1)

            label_score += list(zip(target.cpu().data.numpy().tolist(),
                                            scores.tolist()))
        # Compute test score
        labels, scores = zip(*label_score)
        labels = np.array(labels)
        scores = np.array(scores)

        if metric == 'AUC':
            thresh = vthresh
            y_pred = np.where(scores >= thresh, 1, 0)#scores >= thresh取1，scores <= thresh取0
            prec, recall, test_metric, _ = precision_recall_fscore_support(
                labels, y_pred)
            #所有无火样本中，被判为有火的概率
            fp=np.sum(y_pred[np.where(labels == 1)] == 0) / np.sum(labels == 1)
            print("误警率:",fp)
            #所有有火样本中，被判为有火的概率,也就是召回率，TP/(TP+FN)=TP/P
            print("火焰检测率:",recall[0])
            test_metric = roc_auc_score(labels, scores)  # labels真实标签，scores预测标签
        e_time = time.time()
        runtime = e_time - s_time

        return test_metric,fp,recall[0],runtime