import os
import random

import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('TkAgg')


plt.rcParams['font.family'] = ['sans-serif']
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
x = np.linspace(0, 7, 100)
y=np.sin(x)
plt.plot(x, y,ls='-', c='black',)


r=0.3
r2=0.6
theta = np.arange(0, 2 * np.pi, 0.01)
c1 = x[50] + r * np.cos(theta)
c2 = np.sin(x[50]) + r * np.sin(theta)

c3 = x[50] + r2 * np.cos(theta)
c4 = np.sin(x[50]) + r2 * np.sin(theta)

c5 = x[45] + r * np.cos(theta)
c6 = np.sin(x[45]) + r * np.sin(theta)

c7 = x[45] + r2 * np.cos(theta)
c8 = np.sin(x[45]) + r2 * np.sin(theta)


normalx=x[0:100:2]
normaly=np.sin(x[0:100:2])
def check(redx,redy):
    for i in range(50):
        if np.square(redx-normalx[i])+np.square(redy-normaly[i])<=0.09:
            return False
            break
    for j in range(50):
        if np.square(redx-normalx[j])+np.square(redy-normaly[j])<0.36:
            return True



i=0
px=[]
py=[]
randx=[]
randy=[]
while i<=50:
    redx = random.uniform(0,7.1)
    redy = random.uniform(-1.5,1.5)

    # randx.append(redx)
    # randy.append(redy)
    if check(redx,redy):
        px.append(redx)
        py.append(redy)
        i=i+1



txbox=[]
tybox=[]
ind=[]

for i in range(50):
    dbox = []
    for j in range(50):
        d=np.square(normalx[i]-px[j])+np.square(normaly[i]-py[j])
        dbox.append(d)
    dbox=np.array(dbox)
    index=np.argmin(dbox)
    ind.append(index)
    txbox.append(px[index])
    tybox.append(py[index])

plt.scatter(px,  py, c='g', s=15,label="abnormal",marker='+')
# plt.scatter(txbox, tybox, c='blue', s=20,label="abnormal(train)",marker='+')


plt.axis('equal')
plt.plot(c1, c2,ls='-', c='black')
plt.plot(c3, c4,ls='-', c='black')


plt.scatter(x[0:100:2],np.sin(x[0:100:2]),c='r',s=8,label='normal')

plt.legend()
#show出图形
plt.show()
