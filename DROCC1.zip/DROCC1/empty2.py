import os
import time

import cv2
import numpy as np
import pandas as pd
import torch
import torchvision
import xlrd
import xlwt
from PIL import Image
from sklearn.metrics import precision_recall_fscore_support
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from xlutils import copy


class FIRE_LeNetPlus(nn.Module):

    def __init__(self):
        super(FIRE_LeNetPlus, self).__init__()
        self.pool = nn.MaxPool2d(2, 2)

        self.conv1 = nn.Conv2d(3, 32, 3, bias=False, padding=2)
        self.bn2d1 = nn.BatchNorm2d(32, eps=1e-04, affine=False)
        self.conv2 = nn.Conv2d(32, 64, 3, bias=False, padding=2)

        self.bn2d2 = nn.BatchNorm2d(64, eps=1e-04, affine=False)
        self.conv3 = nn.Conv2d(64, 128, 3, bias=False, padding=2)
        self.bn2d3 = nn.BatchNorm2d(128, eps=1e-04, affine=False)
        # self.conv4 = nn.Conv2d(64, 128, 3, bias=False, padding=2)
        # self.bn2d4 = nn.BatchNorm2d(256, eps=1e-04, affine=False)


        # self.lstm = nn.LSTM(input_size=1600, hidden_size=64, batch_first=True)
        # self.drop=nn.Dropout(0.2)
        self.fc3 = nn.Linear(1152, 2, bias=False)

    def forward(self, x):
        x = self.conv1(x)
        x = self.pool(F.leaky_relu(self.bn2d1(x)))
        x = self.conv2(x)

        # x = self.pool(F.leaky_relu(self.bn2d2(x)))
        x = self.conv3(x)
        # x = self.conv4(x)
        x = self.pool(F.leaky_relu(self.bn2d3(x)))

        x = x.view(x.size(0), -1)
        # x,_=self.lstm(x)
        # x=self.drop(x)
        x = F.softmax(F.leaky_relu(self.fc3(x)))
        return x



train_datadir = r'F:\videofireimg\cropvideo2-twocls\train2'
test_datadir  = r'F:\videofireimg\cropvideo2-twocls\train2'

# #准备工作
train_data=torchvision.datasets.ImageFolder(train_datadir,transform=torchvision.transforms.ToTensor())
test_data=torchvision.datasets.ImageFolder(test_datadir,transform=torchvision.transforms.ToTensor())
train_data_size=len(train_data)
test_data_size=len(test_data)
print("训练集长度为{}".format(train_data_size))
print("测试集长度为{}".format(test_data_size))

train_dataload=DataLoader(train_data,batch_size=64,shuffle=True)
test_dataload=DataLoader(test_data,batch_size=64)
#
use_cuda = torch.cuda.is_available()
device = torch.device("cuda" if use_cuda else "cpu")
# # #建立模型
tudui=FIRE_LeNetPlus().to(device)

#损失函数
loss_fn=nn.CrossEntropyLoss().to(device)
#优化器
learning_rate=0.0002
optimizer=torch.optim.SGD(tudui.parameters(),lr=learning_rate)
#记录训练次数与测试次数
total_train_step=0
total_test_step=0
#训练轮数
epoch=20

# writer=SummaryWriter("../logs_train")
for i in range(epoch):
    print("------------------第{}轮训练-------------------".format(i))
    #开始训练
    for data in train_dataload:
        #取数据
        img,target=data[0].to(device),data[1].to(device)

        img = img.to(torch.float)
        # target = target.to(torch.float)
        # target = torch.squeeze(target)

        output=tudui(img)
        # output = torch.squeeze(output, dim=1)
        loss=loss_fn(output,target)

        #优化器
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_train_step=total_train_step+1
        if total_train_step%100==0:
            print("训练次数：{}   loss:{}".format(total_train_step,loss.item()))
            # writer.add_scalar("train_loss",loss.item(),total_train_step)

    #开始测试
    label_score = []
    total_test_loss=0
    total_accuracy=0
    with torch.no_grad():
        for data in test_dataload:
            img, target = data[0].to(device),data[1].to(device)
            output = tudui(img)
            loss = loss_fn(output, target)
            total_test_loss=total_test_loss+loss.item()
            output = torch.max(output, dim=1)[1]
            label_score += list(zip(target.data.cpu().numpy().tolist(),
                                    output.data.cpu().numpy().tolist()))
    target, output = zip(*label_score)
    target = np.array(target)
    output = np.array(output)
    # prec, recall, test_metric, _ = precision_recall_fscore_support(
    #     target, output)
    print("误警率:",np.sum(output[np.where(target == 1)] == 0) / np.sum(target == 1))
    print("火焰检测率:", np.sum(output[np.where(target == 0)] == 0) / np.sum(target == 0))
    print("整体数据集上Loss：{}".format(total_test_loss))
    # writer.add_scalar("test_loss", total_test_loss, total_test_step)
    total_test_step=total_test_step+1
# writer.close()
    torch.save(tudui, "twocls/tudui_{}.pth".format(i))
print("模型已保存")



def real_time_val(f, cutsize, frame):
    s_time = time.time()
    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    # 宽度854再加42，左右各加21，高度288再加48，上下各加24,分块56x56
    # borderType = cv2.BORDER_REFLECT指边界反射填充(以边界为轴对称填充)
    top_btm = 0
    left_rgt = 1
    replicate = cv2.copyMakeBorder(img, top_btm, top_btm, left_rgt, left_rgt, borderType=cv2.BORDER_REFLECT)
    replicate = cv2.cvtColor(replicate, cv2.COLOR_BGR2RGB)
    imgori = replicate
    # imgori=img

    high, width, channel = imgori.shape
    row = high
    col = width
    index = 1

    w = h = cutsize
    y_pred = []
    new_img = Image.new('RGB', (width, high))
    for i in range(row // cutsize):
        for j in range(col // cutsize):
            cropped_image = imgori[i * cutsize:cutsize * (i + 1),
                            cutsize * j:cutsize * (j + 1)]  # Slicing to crop the image

            transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
            img = transform(cropped_image)
            img = img.reshape((1, 3, cutsize, cutsize))
            img = img.to(device)
            # img = img.to(torch.float)

            logits = tudui(img)
            logits = torch.squeeze(logits, dim=1)
            scores = logits

            if torch.max(scores,dim=1)[1]==1:
                imgn = Image.new("RGB", (w, h), "black")  # 新建图像
                y_pred.append(1)
            else:
                img_pil = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                # img_pil = Image.fromarray(cropped_image)
                imgn = img_pil
                # indexbox.append(index)
                y_pred.append(0)
            index = index + 1

            new_img.paste(imgn, (j * h, i * w))
    e_time = time.time()
    runtime = e_time - s_time
    # new_img.save(r'/mnt/videofireimg/cropvideo2-twocls/val/4px_result_frame{}.png'.format(f))
    # new_img.save(r'F:\videofireimg\flamevideo-twocls\val\lstmres\4px_result_frame{}.png'.format(f))

    return runtime, y_pred



 # 实时验证
tudui = torch.load("./twocls/tudui_19.pth")
cutsize = 4
read = xlrd.open_workbook(r'F:\videofireimg\cropvideo2-onecls\four_four\val\cropvideo2_label.xlsx')
# data=pd.read_csv(r'D:\label25s_3min22.csv')
# path = r'C:\Users\Lenovo\Desktop\OneClassDemo-main\cropvideo2_'
# import h5py
# matdata = h5py.File(path)
# Label = np.transpose(np.array(matdata.get('B')))
# read = xlrd.open_workbook(r'F:\videofireimg\flame-onecls\four_four\val\flame_label2.xlsx')
sheet1 = read.sheet_by_index(0)
row = sheet1.nrows
col = sheet1.ncols
# row = Label.shape[0]
# col = Label.shape[1]
print(row, col)
Label = []
timebox = []
TPbox = []
FPbox = []
for y in range(col):
    Label.append([])

for y in range(col):
    for x in range(row):
        if sheet1.cell_value(x, y) != '':
            t = sheet1.cell_value(x, y)
            Label[y].append(t)
    Label[y] = np.array(Label[y])

# cap = cv2.VideoCapture(r'/mnt/videofireimg/cropvideo2-onecls/four_four/val/CropVedio2.mp4')
cap = cv2.VideoCapture(r'C:\Users\Lenovo\Desktop\OneClassDemo-main\CropVedio2.mp4')
index = []
# framenum = 5219
print('总帧数：', int(cap.get(cv2.CAP_PROP_FRAME_COUNT)))
for k in range(1, int(cap.get(cv2.CAP_PROP_FRAME_COUNT))+1, 3):
# for k in range(1, framenum + 1, 1):
    if k + 2 <= int(cap.get(cv2.CAP_PROP_FRAME_COUNT)):
        index.append(k + 1)
        index.append(k + 2)
    elif k + 1 <= int(cap.get(cv2.CAP_PROP_FRAME_COUNT)):
        index.append(k + 1)
    # index.append(k)

print('index len:', len(index))

f = 1
i =0
num=1
t=0
while True:
    # 逐帧读取视频
    ret, frame = cap.read()
    # frame = cv2.imread(r'F:\videofireimg\flamevideo-onecls\four_four\val\ori25s-3min22\ori{}.png'.format(f))
    if not ret:
        break
    # if f > framenum:
    #     break
    if f in index:
        print("f",f)

        res = real_time_val(f,cutsize, frame)
        # timebox.append(res[0])
        print("运行时间{}".format(res[0]))
        y_pred = np.array(res[1])

        print("误警率:", np.sum(y_pred[np.where(Label[i] == 1)] == 0) / np.sum(Label[i] == 1))
        FPbox.append(np.sum(y_pred[np.where(Label[i] == 1)] == 0) / np.sum(Label[i] == 1) * 100)
        print("火焰检测率:", np.sum(y_pred[np.where(Label[i] == 0)] == 0) / np.sum(Label[i] == 0))
        TPbox.append(np.sum(y_pred[np.where(Label[i] == 0)] == 0) / np.sum(Label[i] == 0) * 100)

        # print("误警率:", np.sum(y_pred[np.where(Label[:, i:i + 1] == 1)[0]] == 0) / np.sum(Label[:, i:i + 1] == 1))
        # FPbox.append(np.sum(y_pred[np.where(Label[:, i:i + 1] == 1)[0]] == 0) / np.sum(Label[:, i:i + 1] == 1) * 100)
        # print("火焰检测率:", np.sum(y_pred[np.where(Label[:, i:i + 1] == 0)[0]] == 0) / np.sum(Label[:, i:i + 1] == 0))
        # TPbox.append(np.sum(y_pred[np.where(Label[:, i:i + 1] == 0)[0]] == 0) / np.sum(Label[:, i:i + 1] == 0) * 100)
        print("***********************")
        # print(TPbox)
        # print(FPbox)
        # path = r'F:\videofireimg\flamevideo-twocls\val\lcnetres.xls'
        # xls = xlrd.open_workbook(path, formatting_info=True)  # 得到文件
        # workbook = copy.copy(xls)  # 复制文件并保留格式
        # worksheet = workbook.get_sheet(0)  # 打开表单
        # # workbook = xlwt.Workbook(encoding='utf-8')
        # # worksheet = workbook.add_sheet('sheet1')
        # if num==10:
        #     for x in range(10):
        #         worksheet.write(t, 0, TPbox[x])
        #         worksheet.write(t, 1, FPbox[x])
        #         t=t+1
        #     workbook.save(path)
        #     num=1
        #     TPbox=[]
        #     FPbox=[]
        # else:
        #     num=num+1
        # print("-------------------------------------")
        i = i + 1
    f = f + 1
# 释放资源并关闭窗口
cap.release()
cv2.destroyAllWindows()

# drawPic(TPbox,FPbox,index)

# path = r'/mnt/videofireimg/cropvideo2-twocls/cropvideo2_res.xls'
# path = r'F:\videofireimg\flamevideo-twocls\val\lstmres.xls'
# # 创建可写的workbook对象
# workbook = xlwt.Workbook(encoding='utf-8')
# # 创建工作表sheet
# worksheet = workbook.add_sheet('sheet1')
#
# for x in range(len(TPbox)):
#     worksheet.write(x, 0, TPbox[x])
#     worksheet.write(x, 1, FPbox[x])
# # 保存表
# workbook.save(path)
