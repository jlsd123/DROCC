import time

import cv2
import numpy as np
import torch
import torchvision
import xlrd
import xlwt
from PIL import Image
from sklearn.metrics import precision_recall_fscore_support
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from resnet import MyResNet

# train_datadir = r'/mnt/videofireimg/cropvideo2-twocls/train'
# test_datadir  = r'/mnt/videofireimg/cropvideo2-twocls/test'
train_datadir = r'F:\videofireimg\cropvideo2-twocls\train'
test_datadir  = r'F:\videofireimg\cropvideo2-twocls\test'

#准备工作
train_data=torchvision.datasets.ImageFolder(train_datadir,transform=torchvision.transforms.ToTensor())
test_data=torchvision.datasets.ImageFolder(test_datadir,transform=torchvision.transforms.ToTensor())
train_data_size=len(train_data)
test_data_size=len(test_data)
print("训练集长度为{}".format(train_data_size))
print("测试集长度为{}".format(test_data_size))

train_dataload=DataLoader(train_data,batch_size=64)
test_dataload=DataLoader(test_data,batch_size=64)


# #建立模型
# batch_size = 4
# 如果cuda加速可用，则使用cuda加速，否则使用CPU
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
# 设置分类标签
classes = ('fire', 'nofire')

# 实例化网络
net = MyResNet()

# 用SGD训练网络
net.train_net(train_dataload, device=device, epochs=30, optimizer='SGD')
net.save_net(path='twocls/resnet.pth')
# 画损失图
net.draw_loss()
# 在测试集上测试网络
# scores=net.test_net(test_dataload, classes, device=device)
# print(scores)
# net.load_net("./twocls/resnet.pth")


def real_time_val( f, cutsize, frame):
    s_time = time.time()
    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    # 宽度854再加42，左右各加21，高度288再加48，上下各加24,分块56x56
    # borderType = cv2.BORDER_REFLECT指边界反射填充(以边界为轴对称填充)
    top_btm = 0
    left_rgt = 1
    replicate = cv2.copyMakeBorder(img, top_btm, top_btm, left_rgt, left_rgt, borderType=cv2.BORDER_REFLECT)
    replicate = cv2.cvtColor(replicate, cv2.COLOR_BGR2RGB)
    imgori = replicate
    # imgori=img

    high, width, channel = imgori.shape
    row = high
    col = width
    index = 1

    w = h = cutsize
    y_pred = []
    new_img = Image.new('RGB', (width, high))
    net.eval()
    for i in range(row // cutsize):
        for j in range(col // cutsize):
            cropped_image = imgori[i * cutsize:cutsize * (i + 1),
                            cutsize * j:cutsize * (j + 1)]  # Slicing to crop the image

            transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
            img = transform(cropped_image)
            img = img.reshape((1, 3, 4, 4))
            img = img.to(device)
            img = img.to(torch.float)

            logits = net(img)
            logits = torch.squeeze(logits, dim=1)
            scores = logits

            if torch.max(scores,dim=1)[1]==1:
                imgn = Image.new("RGB", (w, h), "black")  # 新建图像
                y_pred.append(1)
            else:
                img_pil = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                # img_pil = Image.fromarray(cropped_image)
                imgn = img_pil
                # indexbox.append(index)
                y_pred.append(0)
            index = index + 1

            new_img.paste(imgn, (j * h, i * w))
    e_time = time.time()
    runtime = e_time - s_time
    # new_img.save(r'/mnt/videofireimg/cropvideo2-twocls/val/4px_result_frame{}.png'.format(f))
    new_img.save(r'F:\videofireimg\cropvideo2-twocls\val\4px_result_frame{}.png'.format(f))

    return runtime, y_pred




 # 实时验证
cutsize = 4
# read = xlrd.open_workbook(r'/mnt/videofireimg/cropvideo2-onecls/four_four/val/cropvideo2_label.xlsx')
read = xlrd.open_workbook(r'F:\videofireimg\cropvideo2-onecls\four_four\val\cropvideo2_label.xlsx')
sheet1 = read.sheet_by_index(0)
row = sheet1.nrows
col = sheet1.ncols
print(row, col)
Label = []
timebox = []
TPbox = []
FPbox = []
for y in range(col):
    Label.append([])

for y in range(col):
    for x in range(row):
        if sheet1.cell_value(x, y) != '':
            t = sheet1.cell_value(x, y)
            Label[y].append(t)
    Label[y] = np.array(Label[y])

# cap = cv2.VideoCapture(r'/mnt/videofireimg/cropvideo2-onecls/four_four/val/CropVedio2.mp4')
cap = cv2.VideoCapture(r'E:\OneClassDemo\CropVedio2.mp4')
index = []
print('总帧数：', int(cap.get(cv2.CAP_PROP_FRAME_COUNT)))
for k in range(1, int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), 3):
    if k + 2 <= int(cap.get(cv2.CAP_PROP_FRAME_COUNT)):
        index.append(k + 1)
        index.append(k + 2)
    elif k + 1 <= int(cap.get(cv2.CAP_PROP_FRAME_COUNT)):
        index.append(k + 1)

print('index len:', len(index))

f = 1
i = 0
while True:
    # 逐帧读取视频
    ret, frame = cap.read()
    if not ret:
        break
    if f in index:
        print(f)

        res = real_time_val(f,cutsize, frame)
        timebox.append(res[0])
        print("运行时间{}".format(res[0]))
        y_pred = np.array(res[1])

        print("误警率:", np.sum(y_pred[np.where(Label[i] == 1)] == 0) / np.sum(Label[i] == 1))
        FPbox.append(np.sum(y_pred[np.where(Label[i] == 1)] == 0) / np.sum(Label[i] == 1) * 100)
        print("火焰检测率:", np.sum(y_pred[np.where(Label[i] == 0)] == 0) / np.sum(Label[i] == 0))
        TPbox.append(np.sum(y_pred[np.where(Label[i] == 0)] == 0) / np.sum(Label[i] == 0) * 100)
        print("***********************")
        i = i + 1
    f = f + 1
# 释放资源并关闭窗口
cap.release()
cv2.destroyAllWindows()

# drawPic(TPbox,FPbox,index)

# path = r'/mnt/videofireimg/cropvideo2-twocls/cropvideo2_res.xls'
path = r'F:\videofireimg\cropvideo2-twocls\cropvideo2_res.xls'
# 创建可写的workbook对象
workbook = xlwt.Workbook(encoding='utf-8')
# 创建工作表sheet
worksheet = workbook.add_sheet('sheet1')

for x in range(len(TPbox)):
    worksheet.write(x, 0, TPbox[x])
    worksheet.write(x, 1, FPbox[x])
# 保存表
workbook.save(path)
