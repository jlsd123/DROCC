import os
import time

import cv2
import numpy as np
import pandas as pd
import torch
import torchvision
import xlrd
import xlwt
from PIL import Image
from sklearn.metrics import precision_recall_fscore_support
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from xlutils import copy


class FIRE_LeNetPlus(nn.Module):

    def __init__(self):
        super(FIRE_LeNetPlus, self).__init__()
        self.pool = nn.MaxPool2d(2, 2)

        self.conv1 = nn.Conv2d(3, 32, 7, bias=False, padding=2)
        self.bn2d1 = nn.BatchNorm2d(32, eps=1e-04, affine=False)
        self.conv2 = nn.Conv2d(32, 64,5, bias=False, padding=2)
        self.bn2d2 = nn.BatchNorm2d(64, eps=1e-04, affine=False)
        self.conv3 = nn.Conv2d(64, 128, 3, bias=False, padding=2)
        self.bn2d3 = nn.BatchNorm2d(128, eps=1e-04, affine=False)
        self.conv4 = nn.Conv2d(128, 256, 3, bias=False, padding=2)
        self.bn2d4 = nn.BatchNorm2d(256, eps=1e-04, affine=False)


        self.lstm = nn.LSTM(input_size=278784, hidden_size=64, batch_first=True)
        self.drop=nn.Dropout(0.2)
        self.fc3 = nn.Linear(64, 2, bias=False)

    def forward(self, x):
        x = self.conv1(x)
        x = self.pool(F.leaky_relu(self.bn2d1(x)))
        x = self.conv2(x)
        x = self.pool(F.leaky_relu(self.bn2d2(x)))
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.pool(F.leaky_relu(self.bn2d4(x)))

        x = x.view(x.size(0), -1)
        x,_=self.lstm(x)
        x=self.drop(x)
        x = F.softmax(self.fc3(x))
        return x


train_datadir = r'/mnt/flameimg/twoclsTrian'
test_datadir  = r'/mnt/flameimg/DROCCvideo'
# train_datadir = r'F:\videofireimg\flamevideo-twocls\train'
# test_datadir  = r'F:\videofireimg\flamevideo-twocls\test'

# #准备工作
train_data=torchvision.datasets.ImageFolder(train_datadir,transform=torchvision.transforms.ToTensor())
test_data=torchvision.datasets.ImageFolder(test_datadir,transform=torchvision.transforms.ToTensor())
train_data_size=len(train_data)
test_data_size=len(test_data)
print("训练集长度为{}".format(train_data_size))
print("测试集长度为{}".format(test_data_size))

train_dataload=DataLoader(train_data,batch_size=4)
test_dataload=DataLoader(test_data,batch_size=4)
#
use_cuda = torch.cuda.is_available()
device = torch.device("cuda" if use_cuda else "cpu")
# # #建立模型
tudui=FIRE_LeNetPlus().to(device)

#损失函数
loss_fn=nn.CrossEntropyLoss().to(device)
#优化器
learning_rate=0.000002
optimizer=torch.optim.SGD(tudui.parameters(),lr=learning_rate)
#记录训练次数与测试次数
total_train_step=0
total_test_step=0
#训练轮数
epoch=0

# writer=SummaryWriter("../logs_train")
for i in range(epoch):
    print("------------------第{}轮训练-------------------".format(i))
    #开始训练
    for data in train_dataload:
        #取数据
        img,target=data[0].to(device),data[1].to(device)

        img = img.to(torch.float)
        # target = target.to(torch.float)
        # target = torch.squeeze(target)

        output=tudui(img)
        # output = torch.squeeze(output, dim=1)
        loss=loss_fn(output,target)

        #优化器
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_train_step=total_train_step+1
        if total_train_step%100==0:
            print("训练次数：{}   loss:{}".format(total_train_step,loss.item()))
            # writer.add_scalar("train_loss",loss.item(),total_train_step)

    #开始测试
    label_score = []
    total_test_loss=0
    total_accuracy=0
    with torch.no_grad():
        for data in test_dataload:
            img, target = data[0].to(device),data[1].to(device)
            output = tudui(img)
            loss = loss_fn(output, target)
            total_test_loss=total_test_loss+loss.item()
            output = torch.max(output, dim=1)[1]
            label_score += list(zip(target.data.cpu().numpy().tolist(),
                                    output.data.cpu().numpy().tolist()))
    target, output = zip(*label_score)
    target = np.array(target)
    output = np.array(output)
    # prec, recall, test_metric, _ = precision_recall_fscore_support(
    #     target, output)
    print("误警率:",np.sum(output[np.where(target == 1)] == 0) / np.sum(target == 1))
    print("火焰检测率:", np.sum(output[np.where(target == 0)] == 0) / np.sum(target == 0))
    print("整体数据集上Loss：{}".format(total_test_loss))
    # writer.add_scalar("test_loss", total_test_loss, total_test_step)
    total_test_step=total_test_step+1
# writer.close()
    torch.save(tudui, "twocls/tudui_{}.pth".format(i))
print("模型已保存")



tudui = torch.load("./twocls/tudui_9lstm.pth")
# 开始测试
label_score = []
total_test_loss = 0
total_accuracy = 0
with torch.no_grad():
    for data in test_dataload:
        img, target = data[0].to(device), data[1].to(device)
        output = tudui(img)
        loss = loss_fn(output, target)
        total_test_loss = total_test_loss + loss.item()
        output = torch.max(output, dim=1)[1]
        label_score += list(zip(target.data.cpu().numpy().tolist(),
                                output.data.cpu().numpy().tolist()))
target, output = zip(*label_score)
target = np.array(target)
output = np.array(output)
# prec, recall, test_metric, _ = precision_recall_fscore_support(
#     target, output)
print("误警率:", np.sum(output[np.where(target == 1)] == 0) / np.sum(target == 1))
print("火焰检测率:", np.sum(output[np.where(target == 0)] == 0) / np.sum(target == 0))
print("整体数据集上Loss：{}".format(total_test_loss))




